export interface Test {
}
