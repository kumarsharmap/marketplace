export class ProjectModel {
  public projectid: number;
  public projectname: string;
}
