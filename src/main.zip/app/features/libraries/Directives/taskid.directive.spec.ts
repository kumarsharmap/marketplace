import { TaskIdDirective } from "./taskid.directive";


describe('TaskdDirective', () => {
  it('should create an instance', () => {
    //const directive = new TaskIdDirective();
    //expect(directive).toBeTruthy();
  });
});
